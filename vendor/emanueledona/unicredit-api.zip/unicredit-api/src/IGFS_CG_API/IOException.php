<?PHP
namespace emanueledona\unicreditApi\IGFS_CG_API;

class IOException extends \Exception {
}

