<h2>Gentile Cliente,</h2>

<h2>la ringraziamo per la sua registrazione e le confermiamo i dati da lei inseriti:</h2>

<p><strong>Nome e Cognome:</strong> {{ $name  }}</p>

<p><strong>Email:</strong> {{ $email  }}</p>

<p><strong>Numero di Telefono:</strong> {{ $phone  }}</p>

<p><strong>Password:</strong> {{ $password  }}</p>

<p>Tali dati le saranno necessari per la prenotazione dell&#39;ombrellone, che&nbsp;potr&agrave; effettuare nei giorni che le saranno comunicati tramite email.<br />
<br />
Cordiali saluti<br />
<br />
<strong>La Direzione</strong></p>
