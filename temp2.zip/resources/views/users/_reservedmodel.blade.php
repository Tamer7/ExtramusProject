<div class="modal" id="myModal">
  <div class="modal-dialog ">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Place info</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <div class="modal-body">
        <div class="alert alert-danger" role="alert">
          Mi dispiace, un utente sta acquistando questo ombrellone!
        </div>
         <a class="btn btn-info float-right" data-dismiss="modal">Close</a>
       </div>

    </div>
  </div>
</div>
