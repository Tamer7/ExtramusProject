<div class="modal" id="bookingStopedModal">
  <div class="modal-dialog ">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Avviso</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <div class="modal-body">

        <div class="text-sm-center">
          <h3> Per effettuare l'acquisto &egrave; necessario inserire nome utente e password </h3>
        </div>

         <a class="btn btn-info float-right" data-dismiss="modal">Close</a>
       </div>

    </div>
  </div>
</div>
