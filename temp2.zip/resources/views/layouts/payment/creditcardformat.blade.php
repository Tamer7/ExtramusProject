


    <br>
    <br>
    <br>
    <div class="container">
      <a type="button" style="float:right;" href="{{ $maparray['paymentCardUrl'] }}" class="btn btn-info">{{ __('Pay') }} »</a>
    </div>
